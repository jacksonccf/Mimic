﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NPC_Movement : MonoBehaviour
{
    public float moveSpeed;
    public Vector3 dir;
    public float turnSpeed;
    float targetAngle;
    Vector3 currentPos;
    bool play = true;
    Vector3 direction;


    // Use this for initialization
    void Start()
    {
        dir = Vector3.up;
        InvokeRepeating("Start1", 0f, 5f);
    }
    void Start1()
    {
        Physics.IgnoreLayerCollision(this.gameObject.layer, this.gameObject.layer);

        play = true;
        direction = Camera.main.ScreenToWorldPoint(new Vector3(Random.Range(5, Screen.width - 5), Random.Range(5, Screen.height - 5), 10)); //random position in x and y
    }
    // Update is called once per frame
    void Update()
    {
        currentPos = transform.position;//current position of gameObject
        if (play)
        { //calculating direction
            dir = direction - currentPos;

            dir.z = 0;
            dir.Normalize();
            play = false;
        }
        Vector3 target = dir * moveSpeed + currentPos;  //calculating target position
        transform.position = Vector3.Lerp(currentPos, target, Time.deltaTime);//movement from current position to target position
        targetAngle = Mathf.Atan2(dir.y, dir.x) * Mathf.Rad2Deg - 90; //angle of rotation of gameobject
        transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.Euler(0, 0, targetAngle), turnSpeed * Time.deltaTime); //rotation from current direction to target direction
    }
    void OnCollisionEnter2D(Collision2D coll)
    {
        Physics.IgnoreLayerCollision(this.gameObject.layer, this.gameObject.layer);

        if (coll.gameObject.tag == "Wall")
        {
            print("Collided with wall");

            moveSpeed = -moveSpeed;

            CancelInvoke();//stop call to start1 method
            direction = Camera.main.ScreenToWorldPoint(new Vector3(Random.Range(5, Screen.width - 5), Random.Range(5, Screen.height - 5), 10)); //random position in x and y
            play = true;
        }
       
    
    }
    void OnCollisionExit2D()
    {
        Physics.IgnoreLayerCollision(this.gameObject.layer, this.gameObject.layer);

        InvokeRepeating("Start1", 2f, 5f);
   }
}

