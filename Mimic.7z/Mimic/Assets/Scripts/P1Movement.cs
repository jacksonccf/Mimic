﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class P1Movement : MonoBehaviour {

	CharacterController playerOne;
		
	public GameObject projectilePrefab;	
	
	public float speed = 1.0f;
	private Vector3 playerOnePosition = Vector3.zero;	
	private List<GameObject> Projectiles = new List<GameObject>();
	private float projectileVelocity;
	private Vector3 Rotation;
	
	
	
	void Start () {
		
		playerOne = GameObject.FindGameObjectWithTag("Player1").GetComponent<CharacterController>();
		projectileVelocity = 30;
		
	}
	
	
	void Update () {
		
		if(Input.GetAxis("P1_Horizontal") != 0 || Input.GetAxis("P1_Vertical") != 0){
			
			playerOnePosition = new Vector3(Input.GetAxisRaw("P1_Horizontal"), Input.GetAxisRaw("P1_Vertical"), 0 );
		
			playerOnePosition = transform.TransformDirection(playerOnePosition);
			
			playerOnePosition *= speed;
		
		}
		
		if (Input.GetButtonDown("P1_Fire")){
			
			GameObject bullet = (GameObject)Instantiate(projectilePrefab, transform.position, Quaternion.identity);
			Projectiles.Add(bullet);
			
	
		}
		
		for ( int i = 0; i < Projectiles.Count ; i++){
			
			GameObject goBullet = Projectiles[i];
			
			if ( goBullet != null){
				
				
				goBullet.transform.Translate(new Vector3(0,1) * Time.deltaTime * projectileVelocity);
				
			}
			
			if ( Projectiles.Count > 3){
				
				for (int x = 0 ; x < Projectiles.Count ; x++){
					
					DestroyObject(goBullet);
					Projectiles.Remove(goBullet);
					
				}
			}
				
		}
		
	 playerOne.Move(playerOnePosition * Time.deltaTime);	
	 
	}
}
