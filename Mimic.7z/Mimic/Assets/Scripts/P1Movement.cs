﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class P1Movement : MonoBehaviour {

	CharacterController playerOne;
		
	public float speed = 1.0f;
	private Vector3 playerOnePosition = Vector3.zero;	
	
	void Start () {
		
		playerOne = GameObject.FindGameObjectWithTag("Player1").GetComponent<CharacterController>();
		
	}
	
	
	void Update () {
		
		if(Input.GetAxis("P1_Horizontal") != 0 || Input.GetAxis("P1_Vertical") != 0){
			
			playerOnePosition = new Vector3(Input.GetAxisRaw("P1_Horizontal"), Input.GetAxisRaw("P1_Vertical"), 0 );
		
			playerOnePosition = transform.TransformDirection(playerOnePosition);
			
			playerOnePosition *= speed;
		
		}
			
		
	 playerOne.Move(playerOnePosition * Time.deltaTime);	
	 
	}
}
