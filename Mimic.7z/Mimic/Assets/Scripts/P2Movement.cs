﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class P2Movement : MonoBehaviour {

	CharacterController playerOne;
		
	public float speed = 1.0f;
	private Vector3 playerOnePosition = Vector3.zero;
	
	void Start () {
		
		playerOne = GameObject.FindGameObjectWithTag("Player2").GetComponent<CharacterController>();
		
	}
	
	
	void Update () {
		
		if(Input.GetAxis("P2_Horizontal") != 0 || Input.GetAxis("P2_Vertical") != 0){
			
			playerOnePosition = new Vector3(Input.GetAxisRaw("P2_Horizontal"), Input.GetAxisRaw("P2_Vertical"), 0 );
		
			playerOnePosition = transform.TransformDirection(playerOnePosition);
			
			playerOnePosition *= speed;
		
		}

		
		
	 playerOne.Move(playerOnePosition * Time.deltaTime);	
	 
	}
}
