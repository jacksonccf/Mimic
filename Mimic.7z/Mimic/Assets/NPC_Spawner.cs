﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NPC_Spawner : MonoBehaviour
{
    public int npcCount = 20;
    public GameObject NPC;
    // Use this for initialization
    void Start()
    {
        for (int i = 0; i < npcCount; i++)
        {
            Vector3 screenPosition = Camera.main.ScreenToWorldPoint(new Vector3(Random.Range(5, Screen.width - 5), Random.Range(5, Screen.height - 5), 10));
            Instantiate(NPC, screenPosition, Quaternion.identity);
        }
    }

    // Update is called once per frame
    void Update()
    {

    }
}
